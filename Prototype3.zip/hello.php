<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta name_"viewport" content+"width=device-width, initial-scale=1">
  <title>My first PHP script</title>
  </head>
  <body>
  <?php
    $name = "Alix";
	print("Hello " . $name);
	?>
	</body>
</html>